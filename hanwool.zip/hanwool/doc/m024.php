<?
$cate_num = 2;
$cate_title = '제품소개';
$page_num = 4;
$page_title = 'HWC540FL';

include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>






Lorem ipsum dolor sit amet. <?= $cate_num ?>







<?php
include_once(G5_THEME_PATH.'/tail.php');
?>