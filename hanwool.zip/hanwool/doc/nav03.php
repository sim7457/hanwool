<a href="/bbs/board.php?bo_table=gal">갤러리</a>
<ul class="submenu">
    <li><a href="/bbs/board.php?bo_table=gal">갤러리</a></li>
</ul>