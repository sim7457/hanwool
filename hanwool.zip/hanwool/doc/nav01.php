<a href="<?= G5_THEME_URL ?>/doc/m011.php"><?= $as_company ?> 소개</a>
<ul class="submenu">
    <li><a href="<?= G5_THEME_URL ?>/doc/m011.php">회사소개</a></li>
    <li><a href="<?= G5_THEME_URL ?>/doc/m012.php">찾아오시는길</a></li>
</ul>

