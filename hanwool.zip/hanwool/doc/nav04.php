<a href="/bbs/board.php?bo_table=nbbs">고객지원</a>
<ul class="submenu">
    <li><a href="/bbs/board.php?bo_table=nbbs">문의게시판</a></li>
    <li><a href="/bbs/board.php?bo_table=pds">자료실</a></li>
    <li><a href="/bbs/board.php?bo_table=nos">공지사항</a></li>
</ul>