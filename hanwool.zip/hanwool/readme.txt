Theme Name: 한울캠핑카 리뉴얼
Theme URI: http://theme.sir.kr/gnuboard5/demo/basic
Maker: SIR
Maker URI: http://sir.kr
Version: 3.0.0
Detail: 베이직 테마는  SIR에서 제공하는 그누보드5 테마입니다. 베이직 테마는 웹표준 및 접근성을 준수합니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html